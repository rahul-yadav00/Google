
Bevs ={} // dutchman.beers_bought
[ {
    "transaction_id": "328",
    "admin_id": "25",
    "beer_id": "1152803",
    "amount": "4",
    "price": "24.90",
    "timestamp": "2014-10-02 16:05:21"
}, {
    "transaction_id": "329",
    "admin_id": "25",
    "beer_id": "1128101",
    "amount": "2",
    "price": "20.60",
    "timestamp": "2014-10-02 16:05:33"
}, {
    "transaction_id": "330",
    "admin_id": "25",
    "beer_id": "1125001",
    "amount": "2",
    "price": "21.90",
    "timestamp": "2014-10-02 16:05:43"
}, {
    "transaction_id": "331",
    "admin_id": "25",
    "beer_id": "157701",
    "amount": "1",
    "price": "36.30",
    "timestamp": "2014-10-02 16:05:56"
}, {
    "transaction_id": "332",
    "admin_id": "25",
    "beer_id": "1129801",
    "amount": "2",
    "price": "19.90",
    "timestamp": "2014-10-02 16:06:07"
}, {
    "transaction_id": "333",
    "admin_id": "25",
    "beer_id": "151503",
    "amount": "24",
    "price": "21.40",
    "timestamp": "2014-10-02 16:06:17"
}, {
    "transaction_id": "334",
    "admin_id": "25",
    "beer_id": "1120801",
    "amount": "1",
    "price": "21.90",
    "timestamp": "2014-10-02 16:06:28"
}, {
    "transaction_id": "335",
    "admin_id": "25",
    "beer_id": "155701",
    "amount": "1",
    "price": "20.90",
    "timestamp": "2014-10-02 16:06:40"
}, {
    "transaction_id": "336",
    "admin_id": "25",
    "beer_id": "168701",
    "amount": "1",
    "price": "21.90",
    "timestamp": "2014-10-02 16:06:50"
}, {
    "transaction_id": "337",
    "admin_id": "25",
    "beer_id": "148001",
    "amount": "2",
    "price": "15.40",
    "timestamp": "2014-10-02 16:07:06"
}, {
    "transaction_id": "338",
    "admin_id": "25",
    "beer_id": "137901",
    "amount": "3",
    "price": "17.50",
    "timestamp": "2014-10-02 16:07:15"
}, {
    "transaction_id": "339",
    "admin_id": "25",
    "beer_id": "1134103",
    "amount": "2",
    "price": "13.50",
    "timestamp": "2014-10-02 16:07:26"
}, {
    "transaction_id": "340",
    "admin_id": "25",
    "beer_id": "167903",
    "amount": "3",
    "price": "16.40",
    "timestamp": "2014-10-02 16:07:37"
}, {
    "transaction_id": "341",
    "admin_id": "25",
    "beer_id": "196303",
    "amount": "2",
    "price": "22.50",
    "timestamp": "2014-10-02 16:07:46"
}]
